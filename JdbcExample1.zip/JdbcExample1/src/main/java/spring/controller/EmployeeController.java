package spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jakarta.servlet.http.HttpServletRequest;
import spring.dao.EmpDAO;
import spring.model.Employee;

@Controller
public class EmployeeController {

	@Autowired
	private EmpDAO empDAO;

	@RequestMapping(value = "/getemployee", method = RequestMethod.GET)
	public String getEmployee(Model model) {
		return "getemp";
	}

	@RequestMapping(value = "/getnodetails", method = RequestMethod.POST)
	public String user(Employee employee, Model model, HttpServletRequest req) {
		System.out.println("Details page Requested");
		System.out.println("Entered empno:" + employee.getEmpNo());
		Employee e = empDAO.getEmployeeByNo(employee.getEmpNo());
		model.addAttribute("empnodata", e);
		return "getempdetails";
	}

	@RequestMapping(value = "/employees", method = RequestMethod.GET)
	public String getAllEmployees(Model model) {
		List<Employee> employees = empDAO.getAllEmployees();

		model.addAttribute("employees", employees);
		return "empdetails";
	}

	// @RequestMapping(value = "/getdelno", method = RequestMethod.GET)
	// public String getEmployee(Model model) {
	// return "getemp";
	// }
	//
	// @RequestMapping(value = "/getnodetails", method = RequestMethod.POST)
	// public String user(@ModelAttribute("eno") Employee employee, Model model) {
	// System.out.println("Details page Requested");
	// System.out.println("Entered empno:" + employee.getEmpNo());
	// Employee e = empDAO.getEmployeeByNo(employee.getEmpNo());
	// model.addAttribute("empnodata", e);
	// return "getempdetails";
	// }

	//
	// @RequestMapping(value = "/employee/update", method = RequestMethod.POST)
	// public String updateEmployee(@ModelAttribute("employee") Employee employee) {
	// empDAO.updateEmployee(employee);
	// return "redirect:/employees";
	// }
	//
	// @RequestMapping(value = "/employee/create", method = RequestMethod.POST)
	// public String createEmployee(@ModelAttribute("employee") Employee employee) {
	// empDAO.createEmployee(employee);
	// return "redirect:/employees";
	// }
	//
	// @RequestMapping(value = "/employee/new", method = RequestMethod.GET)
	// public String newEmployeeForm(Model model) {
	// model.addAttribute("employee", new Employee());
	// return "newEmployee";
	// }
}
